//
//  AppDelegate.h
//  offlinedemo
//
//  Created by macpc on 23/02/16.
//  Copyright (c) 2016 macpc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

