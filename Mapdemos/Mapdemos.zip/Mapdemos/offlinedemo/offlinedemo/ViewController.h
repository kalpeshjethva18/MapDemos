//
//  ViewController.h
//  offlinedemo
//
//  Created by macpc on 23/02/16.
//  Copyright (c) 2016 macpc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>


@interface ViewController : UIViewController<CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    IBOutlet MKMapView *mapview;
}
@end