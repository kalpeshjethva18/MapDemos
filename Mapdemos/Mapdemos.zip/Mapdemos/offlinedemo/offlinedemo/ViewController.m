//
//  ViewController.m
//  offlinedemo
//
//  Created by macpc on 23/02/16.
//  Copyright (c) 2016 macpc. All rights reserved.

#import "ViewController.h"

@interface ViewController ()
{
    IBOutlet UITextField *txtlocations;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    locationManager=[[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [locationManager requestWhenInUseAuthorization];
    }
}
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    CLLocation *currentLocation = newLocation;
    txtlocations.text = [NSString stringWithFormat:@"%f & %f",currentLocation.coordinate.latitude, currentLocation.coordinate.longitude];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end