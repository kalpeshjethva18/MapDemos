//
//  ViewController.h
//  MapDemo
//
//  Created by macpc on 26/11/15.
//  Copyright (c) 2015 macpc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>


@interface ViewController : UIViewController<CLLocationManagerDelegate>
{
    CLLocationManager *locationmanger;
    
    IBOutlet MKMapView *mapview;
}
@property (nonatomic, retain) MKMapView *mapview; //this is your map view
@property (nonatomic, retain) MKPolyline *routeLine; //your line
@property (nonatomic, retain) MKPolylineView *routeLineView; //overlay view


@end
