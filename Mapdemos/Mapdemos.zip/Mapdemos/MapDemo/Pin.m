//
//  Pin.m
//  MapDemo
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import "Pin.h"

@implementation Pin

- (id)initWithCoordinate:(CLLocationCoordinate2D)newCoordinate
{
    self = [super init];
    if (self) {
        _coordinate = newCoordinate;
        _title = @"Static";
        _subtitle = @"Locations";
    }
    return self;
}
@end
