//
//  Pin.h
//  MapDemo
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface Pin : NSObject<MKAnnotation>

@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
- (id)initWithCoordinate:(CLLocationCoordinate2D)newCoordinate;

@end
