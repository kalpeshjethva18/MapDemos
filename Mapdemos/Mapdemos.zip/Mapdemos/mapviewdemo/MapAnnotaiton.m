//
//  MapAnnotaiton.m
//  mapviewdemo
//
//  Created by macpc on 29/07/15.
//  Copyright (c) 2015 macpc. All rights reserved.
//

#import "MapAnnotaiton.h"
#import <MapKit/MapKit.h>


@implementation MapAnnotaiton
-(id)initWithTitle:(NSString *)title andCoordinate:
(CLLocationCoordinate2D)coordinate2d{
    self.title = title;
    self.coordinate =coordinate2d;
    return self;
}
@end
