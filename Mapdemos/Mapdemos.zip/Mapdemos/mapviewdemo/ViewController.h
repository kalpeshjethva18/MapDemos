//
//  ViewController.h
//  mapviewdemo
//
//  Created by macpc on 29/07/15.
//  Copyright (c) 2015 macpc. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>


#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<MKMapViewDelegate, CLLocationManagerDelegate>
{
    MKMapView *mapview;
      //CLLocationManager *locationManager;
    CLLocationManager *locationManager;
    CLGeocoder *geocoder;
    CLPlacemark *placemark;
}

@property (strong, nonatomic) IBOutlet UITextField *txtlatitude;
@property (strong, nonatomic) IBOutlet MKMapView *mapview;

@property (strong, nonatomic) IBOutlet UITextField *txtlongitude;
@property (strong, nonatomic) IBOutlet UILabel *lblgetaddrees;

@property (nonatomic, retain) MKMapView *mapView; //this is your map view
@property (nonatomic, retain) MKPolyline *routeLine; //your line
@property (nonatomic, retain) MKPolylineView *routeLineView; //o



- (IBAction)getlocations:(id)sender;

@end
