//
//  AppDelegate.h
//  mapviewdemo
//
//  Created by macpc on 29/07/15.
//  Copyright (c) 2015 macpc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import <MapKit/MapKit.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate, MKMapViewDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong, nonatomic) ViewController *viewc;
@property(strong, nonatomic) UINavigationController *navi;


@end

