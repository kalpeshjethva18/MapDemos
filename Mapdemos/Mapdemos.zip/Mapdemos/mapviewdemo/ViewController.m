//
//  ViewController.m
//  mapviewdemo
//
//  Created by macpc on 29/07/15.
//  Copyright (c) 2015 macpc. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>


#import <CoreLocation/CoreLocation.h>
#import "MapAnnotaiton.h"
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)



@interface ViewController ()

@end

@implementation ViewController

@synthesize mapview,txtlatitude,txtlongitude,lblgetaddrees;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
  //  NSString *urlString = [NSString stringWithFormat:@"http://maps.google.com/maps?saddr=%f,%f&daddr=%f,%f", currentLatitude, currentLongitude, destinationLatitude, destinationLongitude];
  //  [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    
}
- (void)handleLongPress:(UIGestureRecognizer *)gestureRecognizer
{
    if (gestureRecognizer.state != UIGestureRecognizerStateBegan)
        return;
    CGPoint touchPoint = [gestureRecognizer locationInView:mapview];
    CLLocationCoordinate2D touchMapCoordinate =
    [mapview convertPoint:touchPoint toCoordinateFromView:mapview];
    MapAnnotaiton *annot = [[MapAnnotaiton alloc] init];
    annot.coordinate = touchMapCoordinate;
    [self.mapview removeAnnotations:self.mapview.annotations];
    
    CLLocationCoordinate2D location2;
    location2.latitude = annot.coordinate.latitude;
    location2.longitude = annot.coordinate.longitude;
  
    
    CLLocationCoordinate2D coordinatearray[2];
    coordinatearray[0] = CLLocationCoordinate2DMake(location2.latitude, location2.longitude);
    coordinatearray[1] = CLLocationCoordinate2DMake(23.0325456, 80.000123);
    
    self.routeLine = [MKPolyline polylineWithCoordinates:coordinatearray count:2];
    [self.mapView setVisibleMapRect:[self.routeLine boundingMapRect]]; //If you want the route to be visible
    [self.mapView addOverlay:self.routeLine];
    
    
    txtlongitude.text = [NSString stringWithFormat:@"%.8f", annot.coordinate.longitude];
    txtlatitude.text = [NSString stringWithFormat:@"%.8f", annot.coordinate.latitude];
    
    
    

    CLLocation *currentLocation = [[CLLocation alloc]initWithCoordinate:location2 altitude:1 horizontalAccuracy:1 verticalAccuracy:-1 timestamp:[NSDate date]];
    
    
    
    [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        NSLog(@"Found placemarks: %@, error: %@", placemarks, error);
        if (error == nil && [placemarks count] > 0) {
            placemark = [placemarks lastObject];
            lblgetaddrees.text = [NSString stringWithFormat:@"%@ %@\n%@ %@\n%@\n%@",
                                  placemark.subThoroughfare, placemark.thoroughfare,
                                  placemark.postalCode, placemark.locality,
                                  placemark.administrativeArea,
                                  placemark.country];
            
            MapAnnotaiton *newAnnotation2 = [[MapAnnotaiton alloc]
                                             initWithTitle:lblgetaddrees.text andCoordinate:location2];
            [mapview addAnnotation:newAnnotation2];
            [self.view addSubview:mapview];
            
            
        } else {
            NSLog(@"%@", error.debugDescription);
        }
    } ];
}
-(MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    if(overlay == self.routeLine)
    {
        if(nil == self.routeLineView)
        {
            self.routeLineView = [[MKPolylineView alloc] initWithPolyline:self.routeLine];
            self.routeLineView.fillColor = [UIColor redColor];
            self.routeLineView.strokeColor = [UIColor redColor];
            self.routeLineView.lineWidth = 5;
        }
        return self.routeLineView;
    }
    return nil;
}
- (IBAction)getlocations:(id)sender{
    
    locationManager = [[CLLocationManager alloc]init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBestForNavigation];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [locationManager requestWhenInUseAuthorization];
       // [locationManager requestAlwaysAuthorization];
    }
    [locationManager startUpdatingLocation];
}
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}
- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    [mapView deselectAnnotation:view.annotation animated:YES];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"didUpdateToLocation: %@", newLocation);
    
    CLLocation *currentLocation = newLocation;
    
    if (currentLocation != nil) {
        txtlongitude.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        txtlatitude.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        
        MKMapCamera *newCamera=[[MKMapCamera alloc] init];
        [newCamera setCenterCoordinate:CLLocationCoordinate2DMake(currentLocation.coordinate.latitude,currentLocation.coordinate.longitude)];
        [newCamera setAltitude:600.0];
        [mapview setCamera:newCamera animated:YES];
    }
   // [locationManager stopUpdatingLocation];
    
    NSLog(@" ");
    [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        NSLog(@"Found placemarks: %@, error: %@", placemarks, error);
        if (error == nil && [placemarks count] > 0) {
            placemark = [placemarks lastObject];
            lblgetaddrees.text = [NSString stringWithFormat:@"%@ %@\n%@ %@\n%@\n%@",
                                 placemark.subThoroughfare, placemark.thoroughfare,
                                 placemark.postalCode, placemark.locality,
                                 placemark.administrativeArea,
                                 placemark.country];
            MapAnnotaiton *newAnnotation = [[MapAnnotaiton alloc]
                                            initWithTitle:lblgetaddrees.text andCoordinate:currentLocation.coordinate];
            [mapview addAnnotation:newAnnotation];
        } else {
            NSLog(@"%@", error.debugDescription);
        }
    } ];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
@end