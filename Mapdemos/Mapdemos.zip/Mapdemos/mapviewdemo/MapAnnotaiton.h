//
//  MapAnnotaiton.h
//  mapviewdemo
//
//  Created by macpc on 29/07/15.
//  Copyright (c) 2015 macpc. All rights reserved.
//
/*
#import <Foundation/Foundation.h>

@interface MapAnnotaiton : NSObject

@end
 */
#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>


@interface MapAnnotaiton : NSObject<MKAnnotation>

@property (nonatomic, strong) NSString *title;
@property (nonatomic, readwrite) CLLocationCoordinate2D coordinate;

- (id)initWithTitle:(NSString *)title andCoordinate:
(CLLocationCoordinate2D)coordinate2d;

@end