//
//  wscalllogview.m
//  CouProm
//
//  Created by Harshul Shah on 25/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import "wscalllogview.h"
#import "AppDelegate.h"
#import "wscalllogclass.h"

@implementation wscalllogview
@synthesize wscallLogArray;
@synthesize wsLogScrollView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    [self BindWsLog];
}

-(void)BindWsLog
{
    //AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
  //  wscallLogArray = [appDelegate wsCallLogArray];
    
    if(wscallLogArray.count > 0)
    {
        int x=5;
        int y=0;
        wscalllogclass *wsCallObj ;  
        for(int i=0;i<wscallLogArray.count;i++)
        {
            x = 0;
            if( y == 0)
            {
                y = 2;
            }
            else
            {
                y = y+32;
            }
            wsCallObj = [wscallLogArray objectAtIndex:i];
            
            
            
            UILabel *lblTimeText = [[UILabel alloc]init];
            lblTimeText.frame = CGRectMake(x, y, 62, 21);
            lblTimeText.text = @"Time = ";
            [wsLogScrollView  addSubview:lblTimeText];
            
            
            
            x = x + 84;
            
            UILabel *lblTime = [[UILabel alloc]init];
            lblTime.frame = CGRectMake(x, y, 223, 21);
            lblTime.text = wsCallObj.time;
            [wsLogScrollView addSubview:lblTime];
            
            
            y = y +32;
            x = 0;
            
            
            UILabel *lblPlaceText = [[UILabel alloc]init];
            lblPlaceText.frame = CGRectMake(x, y, 70, 21);
            lblPlaceText.text = @"Place = ";
            [wsLogScrollView addSubview:lblPlaceText];
            
            x = x+84;
            
            UILabel *lblPlace = [[UILabel alloc]init];
            lblPlace.frame = CGRectMake(x, y, 223, 21);
            lblPlace.text = wsCallObj.place;
            [wsLogScrollView addSubview:lblPlace];

            x = 2;
            y = y + 35;
            UIImageView *imgLine= [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"solid-line.png"]];
            
            imgLine.frame = CGRectMake(x, y, 272, 1);
            [wsLogScrollView addSubview:imgLine]; 

            
        }
        
        wsLogScrollView.contentSize = CGSizeMake(320, y + 100);
        
    }

}



- (void)viewDidUnload
{
    [self setWsLogScrollView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
   }
@end
