//
//  wscalllogclass.h
//  CouProm
//
//  Created by Harshul Shah on 25/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface wscalllogclass : NSObject

@property(nonatomic,retain)NSString *time;
@property(nonatomic,retain)NSString *place;


@end
