//
//  locationtrackingview.m
//  CouProm
//
//  Created by Harshul Shah on 21/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import "locationtrackingview.h"
#import "locationtrackingclass.h"
#import "AppDelegate.h"

@implementation locationtrackingview
@synthesize locationTrackingScrollview;

@synthesize locationTrackingArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    [self BindLocationTrackingData];
}



-(void)BindLocationTrackingData
{
    
 //   AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
 ///   locationTrackingArray = [appDelegate locationTrackingArray];
    
    NSLog(@"Location Tracking Array = %@",locationTrackingArray);
    
    if(locationTrackingArray.count > 0)
    {
        int x=5;
        int y=0;
        locationtrackingclass  *trackingObj ;  
        for(int i=0;i<locationTrackingArray.count;i++)
        {
            x = 0;
            if( y == 0)
            {
                y = 2;
            }
            else
            {
                y = y+32;
            }
            trackingObj = [locationTrackingArray objectAtIndex:i];
            
            
            
            UILabel *lblTimeText = [[UILabel alloc]init];
            lblTimeText.frame = CGRectMake(x, y, 62, 21);
            lblTimeText.text = @"Time = ";
            [locationTrackingScrollview addSubview:lblTimeText];
            
            
            
            x = x + 84;
            
            UILabel *lblTime = [[UILabel alloc]init];
            lblTime.frame = CGRectMake(x, y, 223, 21);
            lblTime.text = trackingObj.time;
            [locationTrackingScrollview addSubview:lblTime];
            
            
            
            y = y +32;
            x = 0;
            
            
            UILabel *lblTypeText = [[UILabel alloc]init];
            lblTypeText.frame = CGRectMake(x, y, 70, 21);
            lblTypeText.text = @"Type = ";
            [locationTrackingScrollview addSubview:lblTypeText];
            
            x = x+84;
            
            UILabel *lblType = [[UILabel alloc]init];
            lblType.frame = CGRectMake(x, y, 223, 21);
            lblType.text = trackingObj.type;
            [locationTrackingScrollview addSubview:lblType];
            
            
            x = 0;
            y = y + 32;
            
            UILabel *lbllatitudetext = [[UILabel alloc]init];
            lbllatitudetext.frame = CGRectMake(x, y, 87, 21);
            lbllatitudetext.text =@"Cur.Latitude =";
            [locationTrackingScrollview addSubview:lbllatitudetext];
            
            
            x = x + 84; 
            UILabel *lbllatitude = [[UILabel alloc]init];
            lbllatitude.frame = CGRectMake(x, y, 223, 21);
            lbllatitude.text = trackingObj.curLatitude;
            [locationTrackingScrollview addSubview:lbllatitude];
            
            
            x = 0;
            y = y+32; 
            
            UILabel *lblLongitudeText = [[UILabel alloc]init];
            lblLongitudeText.frame = CGRectMake(x, y, 87, 21);
            lblLongitudeText.text = @"Cur.longitude = ";
            [locationTrackingScrollview addSubview:lblLongitudeText];
            
            
            x = x + 84; 
            UILabel *lblLongitude = [[UILabel alloc]init];
            lblLongitude.frame = CGRectMake(x, y, 223, 21);
            lblLongitude.text = trackingObj.curLongitude;
            [locationTrackingScrollview addSubview:lblLongitude];
            
            
            x = 0;
            y = y +32;
            
            UILabel *lblDistShalimarText = [[UILabel alloc]init];
            lblDistShalimarText.frame = CGRectMake(x, y, 82, 21);
            lblDistShalimarText.text = @"DistShalimar = ";
            [locationTrackingScrollview addSubview:lblDistShalimarText];
            
            
            
            
            x = x + 84; 
            UILabel *lblDistShalimar = [[UILabel alloc]init];
            lblDistShalimar.frame = CGRectMake(x, y, 223, 21);
            lblDistShalimar.text = trackingObj.distanceShalimar;
            [locationTrackingScrollview addSubview:lblDistShalimar];
            
            
            
            
            x = 0;
            y = y +32;
            
            UILabel *lblVsDistText = [[UILabel alloc]init];
            lblVsDistText.frame = CGRectMake(x, y, 82, 21);
            lblVsDistText.text = @"Dist.V.S = ";
            [locationTrackingScrollview addSubview:lblVsDistText];
            
            
            
            
            x = x + 84; 
            UILabel *lblVSDist = [[UILabel alloc]init];
            lblVSDist.frame = CGRectMake(x, y, 223, 21);
            lblVSDist.text = trackingObj.distanceVS;
            [locationTrackingScrollview addSubview:lblVSDist];
    
            
            x = 2;
            y = y + 35;
            UIImageView *imgLine= [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"solid-line.png"]];
            
            imgLine.frame = CGRectMake(x, y, 272, 1);
            [locationTrackingScrollview addSubview:imgLine]; 
            
            
            
            
            
        }
        
        locationTrackingScrollview.contentSize = CGSizeMake(320, y + 100);
        
    }
    
    
}


- (void)viewDidUnload
{
    [self setLocationTrackingScrollview:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
   
}
@end
