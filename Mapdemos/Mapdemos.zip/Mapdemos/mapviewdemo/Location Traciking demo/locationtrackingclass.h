//
//  locationtrackingclass.h
//  CouProm
//
//  Created by Harshul Shah on 21/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface locationtrackingclass : NSObject



@property(nonatomic,retain)NSString *time;
@property(nonatomic,retain)NSString *type;
@property(nonatomic,retain)NSString *distanceShalimar;
@property(nonatomic,retain)NSString *distanceVS;
@property(nonatomic,retain)NSString *place;
@property(nonatomic,retain)NSString *curLatitude;
@property(nonatomic,retain)NSString *curLongitude;



@end
