//
//  wscalllogview.h
//  CouProm
//
//  Created by Harshul Shah on 25/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface wscalllogview : UIViewController


@property(nonatomic,retain)NSMutableArray   *wscallLogArray;

@property (retain, nonatomic) IBOutlet UIScrollView *wsLogScrollView;

-(void)BindWsLog;


@end
