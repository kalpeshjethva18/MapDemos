//
//  trackingclass.m
//  GeoLocationDemo
//
//  Created by Harshul Shah on 18/10/13.
//  Copyright (c) 2013 shah.harshul@yahoo.com. All rights reserved.
//

#import "trackingclass.h"

@implementation trackingclass


@synthesize type,place,latitude,longitude,time;


@end
