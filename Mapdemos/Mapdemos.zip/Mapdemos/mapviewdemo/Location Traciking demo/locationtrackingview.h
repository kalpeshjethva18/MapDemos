//
//  locationtrackingview.h
//  CouProm
//
//  Created by Harshul Shah on 21/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface locationtrackingview : UIViewController



@property (retain, nonatomic) IBOutlet UIScrollView *locationTrackingScrollview;


@property(nonatomic,retain)NSMutableArray *locationTrackingArray;



-(void)BindLocationTrackingData;


@end
