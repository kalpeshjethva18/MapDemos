//
//  getlocationview.h
//  CouProm
//
//  Created by Harshul Shah on 18/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface getlocationview : UIViewController<CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
}

- (IBAction)GetLocation:(id)sender;

@property (strong, nonatomic) IBOutlet UILabel *lblLongitude;
@property (strong, nonatomic) IBOutlet UILabel *lblLatitude;


@property(nonatomic,retain)NSMutableArray *logArray;

@property (retain, nonatomic) IBOutlet UIScrollView *locationScrollview;

@property (retain, nonatomic) IBOutlet UILabel *lblSignificantChange;

@property (retain, nonatomic) IBOutlet UILabel *lblTime;

@property(nonatomic,readwrite)int xPosition;
@property(nonatomic,readwrite)int yPosition;
@property(nonatomic,readwrite)int count;


@property (retain, nonatomic) IBOutlet UILabel *lblRegionNotified;

@property(nonatomic,retain)NSMutableArray *locationTrackingArray;

@property (nonatomic, retain) CLLocation *lastLocation;

@property(nonatomic,readwrite)BOOL isCountinuesUpdate;

@property(nonatomic,readwrite)BOOL updateLocation;

@property(nonatomic,retain)NSDate *lastCapturedDate;

@property(nonatomic,retain)NSTimer *locationTimer;

@property(nonatomic,readwrite)int lastHour;
@property(nonatomic,readwrite)int lastMinute;
@property(nonatomic,readwrite)int lastSecond;


- (IBAction)GotoLocationTracking:(id)sender;

- (IBAction)StartTimer:(id)sender;



- (IBAction)GotoViewLog:(id)sender;
- (IBAction)StopLocation:(id)sender;

- (IBAction)RemoveViewLog:(id)sender;

-(void)TimerTest;

- (IBAction)GotoWSCallLogView:(id)sender;

@end

