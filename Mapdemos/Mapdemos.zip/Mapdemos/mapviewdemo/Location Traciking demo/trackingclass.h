//
//  trackingclass.h
//  GeoLocationDemo
//
//  Created by Harshul Shah on 18/10/13.
//  Copyright (c) 2013 shah.harshul@yahoo.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface trackingclass : NSObject


@property(nonatomic,retain)NSString *type;
@property(nonatomic,retain)NSString *place;
@property(nonatomic,retain)NSString *latitude;
@property(nonatomic,retain)NSString *longitude;
@property(nonatomic,retain)NSString *time;


@end
