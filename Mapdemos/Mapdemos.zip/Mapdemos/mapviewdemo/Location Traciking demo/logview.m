//
//  logview.m
//  GeoLocationDemo
//
//  Created by Harshul Shah on 18/10/13.
//  Copyright (c) 2013 shah.harshul@yahoo.com. All rights reserved.
//

#import "logview.h"

#import "trackingclass.h"

#import "AppDelegate.h"

@implementation logview
@synthesize logTrackingArray;
@synthesize logScrollView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    logScrollView.contentSize = CGSizeMake(320, 800);   
    logScrollView.scrollEnabled = YES;
    
    [self BindLogTrackingData];
    
    [[self navigationController] setNavigationBarHidden:NO animated:YES];

}


-(void)BindLogTrackingData
{
    /*
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    
    logTrackingArray = [userDefault objectForKey:@"logArray"];
    */
    
 //   AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
   // logTrackingArray = [appDelegate logArray];
    
    if(logTrackingArray.count > 0)
    {
        int x=5;
        int y=0;
        trackingclass *trackingObj ;  
        for(int i=0;i<logTrackingArray.count;i++)
        {
            x = 0;
            if( y == 0)
            {
                y = 2;
            }
            else
            {
                y = y+32;
            }
            trackingObj = [logTrackingArray objectAtIndex:i];
            
            
            
            UILabel *lblTimeText = [[UILabel alloc]init];
            lblTimeText.frame = CGRectMake(x, y, 62, 21);
            lblTimeText.text = @"Time = ";
            [logScrollView addSubview:lblTimeText];
            
            
                       
            x = x + 84;
            
            UILabel *lblTime = [[UILabel alloc]init];
            lblTime.frame = CGRectMake(x, y, 223, 21);
            lblTime.text = trackingObj.time;
            [logScrollView addSubview:lblTime];

            
                      
            y = y +32;
            x = 0;
            
            
            UILabel *lblPlaceText = [[UILabel alloc]init];
            lblPlaceText.frame = CGRectMake(x, y, 70, 21);
            lblPlaceText.text = @"Place = ";
            [logScrollView addSubview:lblPlaceText];
            
            x = x+84;

            UILabel *lblPlace = [[UILabel alloc]init];
            lblPlace.frame = CGRectMake(x, y, 223, 21);
            lblPlace.text = trackingObj.place;
            [logScrollView addSubview:lblPlace];
            

            x = 0;
            y = y + 32;
            
            UILabel *lbllatitudetext = [[UILabel alloc]init];
            lbllatitudetext.frame = CGRectMake(x, y, 77, 21);
            lbllatitudetext.text =@"Latitude =";
            [logScrollView addSubview:lbllatitudetext];
            
            
            x = x + 84; 
            UILabel *lbllatitude = [[UILabel alloc]init];
            lbllatitude.frame = CGRectMake(x, y, 223, 21);
            lbllatitude.text = trackingObj.latitude;
            [logScrollView addSubview:lbllatitude];


            x = 0;
            y = y+32; 
            
            UILabel *lblLongitudeText = [[UILabel alloc]init];
            lblLongitudeText.frame = CGRectMake(x, y, 77, 21);
            lblLongitudeText.text = @"longitude = ";
            [logScrollView addSubview:lblLongitudeText];
            
            
            x = x + 84; 
            UILabel *lblLongitude = [[UILabel alloc]init];
            lblLongitude.frame = CGRectMake(x, y, 223, 21);
            lblLongitude.text = trackingObj.longitude;
            [logScrollView addSubview:lblLongitude];

            
            x = 0;
            y = y +32;
            
            UILabel *lblTypeText = [[UILabel alloc]init];
            lblTypeText.frame = CGRectMake(x, y, 62, 21);
            lblTypeText.text = @"Type = ";
            [logScrollView addSubview:lblTypeText];

            
            
            
            x = x + 84; 
            UILabel *lblType = [[UILabel alloc]init];
            lblType.frame = CGRectMake(x, y, 223, 21);
            lblType.text = trackingObj.type;
            [logScrollView addSubview:lblType];

            
            
            x = 2;
            y = y + 35;
            UIImageView *imgLine= [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"solid-line.png"]];
            
            imgLine.frame = CGRectMake(x, y, 272, 1);
            [logScrollView addSubview:imgLine]; 
            
            
            

        
        }
        
        logScrollView.contentSize = CGSizeMake(320, y + 100);
    
    }

}


- (void)viewDidUnload
{
    [self setLogScrollView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
