//
//  locationtrackingclass.m
//  CouProm
//
//  Created by Harshul Shah on 21/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import "locationtrackingclass.h"

@implementation locationtrackingclass


@synthesize time,type;
@synthesize place,distanceShalimar,distanceVS;
@synthesize curLatitude,curLongitude;


@end
