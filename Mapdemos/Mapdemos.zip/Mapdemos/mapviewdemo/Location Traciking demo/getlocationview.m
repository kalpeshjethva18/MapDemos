//
//  getlocationview.m
//  CouProm
//
//  Created by Harshul Shah on 18/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import "getlocationview.h"
#import "trackingclass.h"
#import "logview.h"
#import "locationtrackingclass.h"
#import "locationtrackingview.h"
#import "wscalllogview.h"

@implementation getlocationview
@synthesize lblRegionNotified;
@synthesize logArray;
@synthesize locationScrollview;
@synthesize lblSignificantChange;
@synthesize lblTime;
@synthesize lblLatitude,lblLongitude;
@synthesize xPosition,yPosition,count;
@synthesize locationTrackingArray;
@synthesize isCountinuesUpdate;
@synthesize lastLocation;
@synthesize updateLocation;
@synthesize lastCapturedDate;
@synthesize lastHour,lastMinute,lastSecond;
@synthesize locationTimer;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
-(void)viewWillAppear:(BOOL)animated    
{
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    lblRegionNotified.text = @"";
}

-(void)viewDidAppear:(BOOL)animated 
{
    
}

-(void)TimerTest
{
   
    lastCapturedDate  = [NSDate date];      
    locationTimer = [NSTimer scheduledTimerWithTimeInterval:120
                                                     target:self
                                                   selector:@selector(locationUpdate)
                                                   userInfo:nil
                                                    repeats:YES];
    [locationTimer fire];
    
}

-(void)locationUpdate
{
   // NSLog(@"timer fired..");
    
    isCountinuesUpdate = true;
   // [locationManager stopMonitoringSignificantLocationChanges];
    [locationManager startUpdatingLocation];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
       // Timer work successfully
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    lastHour = 0;
    lastMinute = 0;
    
    xPosition = 5;
    yPosition = 2;
    count = 0;
    locationScrollview.contentSize = CGSizeMake(320, 550);
    locationScrollview.scrollEnabled = YES;
    
    if(locationManager == nil)
    {
        locationManager = [[CLLocationManager alloc] init];
    }
    
    logArray = [[NSMutableArray alloc]init];
    locationTrackingArray = [[NSMutableArray alloc]init];
    
  //  NSArray *regionArray = [[locationManager monitoredRegions] allObjects]; // the all objects is the key
    
    
    /*
    for (int i = 0; i < [regionArray count]; i++)  // loop through array of regions turning them off
    {
        [locationManager stopMonitoringForRegion:[regionArray objectAtIndex:i]];
    }
    */
    /*
    for (CLRegion *monitored in [locationManager monitoredRegions])
        [locationManager stopMonitoringForRegion:monitored];
     */
    
    locationManager.delegate = self;
    
    NSArray *regionArray = [[locationManager monitoredRegions]allObjects];
    
    NSLog(@"Region Array = %@",regionArray);
        
    
    NSSet* set=[locationManager monitoredRegions];
    
    if ([CLLocationManager regionMonitoringAvailable] && [CLLocationManager regionMonitoringEnabled]) {
        NSLog(@"region monitoring okay");
        NSLog(@"monitored regions: %@",set);
    } 
    
   // CLLocationAccuracy acc=kCLLocationAccuracyBest;
    
     //CLLocationDegrees latitude =23.018385;//23.0095879;  //[[dictionary valueForKey:@"latitude"] doubleValue];
    // CLLocationDegrees longitude = 72.571236;//72.56188939999993;  //[[dictionary valueForKey:@"longitude"] doubleValue];
   //  CLLocationCoordinate2D centerCoordinate = CLLocationCoordinate2DMake(latitude, longitude);
     
     //CLLocationCoordinate2D p = CLLocationCoordinate2DMake(23.031672, 72.570266);
     
     
    // CLRegion *reg=[[CLRegion alloc] initCircularRegionWithCenter:centerCoordinate radius:200.0 identifier:@"V.S Hospital"];
     
  //   [locationManager startMonitoringForRegion:reg desiredAccuracy:acc];
     
    
    
    
    //CLLocationDegrees latitude2 =23.009912;//23.0095879;  //[[dictionary valueForKey:@"latitude"] doubleValue];
   // CLLocationDegrees longitude2 = 72.562266;//72.56188939999993;  //[[dictionary valueForKey:@"longitude"] doubleValue];
   // CLLocationCoordinate2D centerCoordinate2 = CLLocationCoordinate2DMake(latitude2, longitude2);
    
    //CLLocationCoordinate2D p = CLLocationCoordinate2DMake(23.031672, 72.570266);
    
    
    //CLRegion *reg2=[[CLRegion alloc] initCircularRegionWithCenter:centerCoordinate2 radius:200.0 identifier:@"Shalimar Complex"];
    
   // [locationManager startMonitoringForRegion:reg2 desiredAccuracy:acc];
    

       
   // [self TimerTest]; 


}

- (IBAction)GetLocation:(id)sender 
{
    
    isCountinuesUpdate = false;
    
    NSString *deviceType = [UIDevice currentDevice].model;
    
    NSLog(@"Device Type = %@",deviceType);
    
    if([deviceType isEqualToString:@"iPhone"] || [deviceType isEqualToString:@"iPhone Simulator"])
    {
        [locationManager startMonitoringSignificantLocationChanges];
        //[locationManager startUpdatingLocation];
    }
    else
    {
        [locationManager startUpdatingLocation];
    }
}
- (IBAction)StopLocation:(id)sender
{
    NSString *deviceType = [UIDevice currentDevice].model;
    if([deviceType isEqualToString:@"iPhone"] || [deviceType isEqualToString:@"iPhone Simulator"])
    {
        [locationManager stopMonitoringSignificantLocationChanges];
        //[locationManager stopUpdatingLocation];
    }
    else
    {
        [locationManager stopUpdatingLocation];
    }
}
#pragma mark - CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}
-(BOOL)CompareTime
{
     NSDate *currentDate = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSInteger comps = (NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit);

    NSDateComponents *date1Components = [calendar components:comps 
                                                    fromDate: lastCapturedDate];
    
    NSDateComponents *date2Components = [calendar components:comps 
                                                    fromDate: currentDate];

    lastCapturedDate = [calendar dateFromComponents:date1Components];
    currentDate = [calendar dateFromComponents:date2Components];

    NSComparisonResult result = [lastCapturedDate compare:currentDate];
    if (result == NSOrderedAscending) 
    {
        NSLog(@"Ascending Time Result = %d",result);
    }
    else if (result == NSOrderedDescending) 
    {
        NSLog(@"Descending Time Time Result = %d",result);
    } 
    else
    {
        NSLog(@"Same Time Result = %d",result);
    }
    return true;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
    
    NSString *deviceType = [UIDevice currentDevice].model;
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    // display in 12HR/24HR (i.e. 11:25PM or 23:25) format according to User Settings
    [dateFormatter setTimeStyle:NSDateFormatterShortStyle];
    NSString *currentTime = [dateFormatter stringFromDate:today];
    NSLog(@"User's current time in their preference format:%@",currentTime);
    
    //lastCapturedDate = today;
        
    NSCalendar *gregorianCal = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *dateComps = [gregorianCal components: (NSHourCalendarUnit | NSMinuteCalendarUnit)
                                                  fromDate: today];
    // Then use it
   // [dateComps minute];
    //[dateComps hour];
    
    
    NSInteger hour = [dateComps hour];
    NSInteger minute = [dateComps minute];
    NSInteger seconds = [dateComps second];
    
    
    
    NSLog(@"Last Hour = %d",lastHour);
    NSLog(@"Current Hour = %ld",(long)hour);
    NSLog(@"Last Minute = %d",lastMinute);
    NSLog(@"Current Minute = %ld",(long)minute);
    
    if(lastHour == 0 && lastMinute  == 0 && lastSecond == 0)
    {
        lastHour = hour;
        lastMinute = minute;
        lastSecond = seconds;
        NSString *locationType = @"";
        if(isCountinuesUpdate)
        {
            isCountinuesUpdate = false;
            locationType = @"Continues";
            [locationManager stopUpdatingLocation];
            [locationManager startMonitoringSignificantLocationChanges];
            
        }
        else
        {
            locationType = @"significant";
        }
        
        //NSString *distance = @"";
        
        CLLocation *shalimarLocation = [[CLLocation alloc] initWithLatitude:23.009912 longitude: 72.562266];
        CLLocation *vshospitalLocation  = [[CLLocation alloc] initWithLatitude:23.018385 longitude:72.571236];
        
        CLLocationDistance shalimarDistance = ([newLocation distanceFromLocation:shalimarLocation]);
        CLLocationDistance vsDistance = ([newLocation distanceFromLocation:vshospitalLocation]);
        
        
        
        NSLog(@"Shaliamr Distance %f in miters",shalimarDistance); //[NSString stringWithFormat:@"%f",shalimarDist]);
        NSLog(@"Vs Distance %f in meters",vsDistance);
        
        
        //distance = distance; 
        
        float shalimarDist = shalimarDistance / 10;
        float vsDist = vsDistance /10;
        
        
        NSLog(@"Shaliamr Distance %f in miters",shalimarDist); //[NSString stringWithFormat:@"%f",shalimarDist]);
        NSLog(@"Vs Distance %f in meters",vsDist);
        
        locationtrackingclass   *locationTracking = [[locationtrackingclass alloc]init];
        
        locationTracking.time = currentTime;
        locationTracking.type = locationType;
        locationTracking.distanceShalimar = [NSString stringWithFormat:@"%.2f",shalimarDist];
        locationTracking.distanceVS = [NSString stringWithFormat:@"%.2f",vsDist];
        locationTracking.curLatitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude];
        locationTracking.curLongitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
        
        [locationTrackingArray addObject:locationTracking];

    }
    
   
    
    else if(lastHour < hour || minute > lastMinute )
    {
        
        lastHour = hour;
        lastMinute = minute;
        NSString *locationType = @"";
        if(isCountinuesUpdate)
        {
            locationType = @"Continues";
            isCountinuesUpdate = false;
            [locationManager stopUpdatingLocation];
            [locationManager startMonitoringSignificantLocationChanges];
            
        }
        else
        {
            locationType = @"significant";
        }
        
        //NSString *distance = @"";
        
        CLLocation *shalimarLocation = [[CLLocation alloc] initWithLatitude:23.009912 longitude: 72.562266];
        CLLocation *vshospitalLocation  = [[CLLocation alloc] initWithLatitude:23.018385 longitude:72.571236];
        
        CLLocationDistance shalimarDistance = ([newLocation distanceFromLocation:shalimarLocation]);
        CLLocationDistance vsDistance = ([newLocation distanceFromLocation:vshospitalLocation]);
        
        
        
        NSLog(@"Shaliamr Distance %f in miters",shalimarDistance); //[NSString stringWithFormat:@"%f",shalimarDist]);
        NSLog(@"Vs Distance %f in meters",vsDistance);
        
        
        //distance = distance; 
        
        float shalimarDist = shalimarDistance / 10;
        float vsDist = vsDistance /10;
        
        
        NSLog(@"Shaliamr Distance %f in miters",shalimarDist); //[NSString stringWithFormat:@"%f",shalimarDist]);
        NSLog(@"Vs Distance %f in meters",vsDist);
        
        locationtrackingclass   *locationTracking = [[locationtrackingclass alloc]init];
        
        locationTracking.time = currentTime;
        locationTracking.type = locationType;
        locationTracking.distanceShalimar = [NSString stringWithFormat:@"%.2f",shalimarDist];
        locationTracking.distanceVS = [NSString stringWithFormat:@"%.2f",vsDist];
        locationTracking.curLatitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude];
        locationTracking.curLongitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
        
        [locationTrackingArray addObject:locationTracking];

    }

    
    //[self CompareTime];
    
    
    NSLog(@"Horizontal Accuracy = %f",newLocation.horizontalAccuracy);

    if([deviceType isEqualToString:@"iPhone"] || [deviceType isEqualToString:@"iPhone Simulator"])
    {
                
       // lblTime.text = [lblTime.text stringByAppendingString:[NSString stringWithFormat:@"%@%@",currentTime,@","]];
        
       // lblSignificantChange.text = [lblSignificantChange.text stringByAppendingString:@"1,"];    
        
        count++;
        UILabel *lblEventCall = [[UILabel alloc]init];
        lblEventCall.frame = CGRectMake(xPosition, yPosition, 223, 41);
        
        lblEventCall.text = [NSString stringWithFormat:@"%d%@%@",count,@" - ",currentTime];
        
        [locationScrollview addSubview:lblEventCall];
        
        yPosition = yPosition + 30;
        
        
        locationScrollview.contentSize = CGSizeMake(320, yPosition + 100);
        
        
    }
    
    NSLog(@"didUpdateToLocation: %@", newLocation);
    CLLocation *currentLocation = newLocation;
    NSDate* eventDate = currentLocation.timestamp;
    NSTimeInterval howRecent = [eventDate timeIntervalSinceNow];
    
    NSLog(@"Recent Coordinate = %d",abs(howRecent));
    
    NSLog(@"Current latitude = %f",currentLocation.coordinate.latitude);
    NSLog(@"Current Longitude = %f",currentLocation.coordinate.longitude);
    
    
    
    
    if (abs(howRecent) < 15.0) 
    {
        lblLongitude.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        lblLatitude.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
    }
}
- (void)locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region
{
    /*   UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Entered" 
     message:region.identifier
     delegate:self
     cancelButtonTitle:@"OK"
     otherButtonTitles:nil, nil];*/
    // [alert show];
    lblRegionNotified.text = @"";
    lblRegionNotified.text = [NSString stringWithFormat:@"%@%@",@"Enter - ",region.identifier];
    
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    // display in 12HR/24HR (i.e. 11:25PM or 23:25) format according to User Settings
    [dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
    NSString *currentTime = [dateFormatter stringFromDate:today];
    NSLog(@"User's current time in their preference format:%@",currentTime);
    
    NSLog(@"Entered Region = %@",region.identifier);
    NSLog(@"Entered Region Latitude = %f",manager.location.coordinate.latitude);
    NSLog(@"Entered Region Longitude = %f",manager.location.coordinate.longitude);
    
    trackingclass *trackingObj = [[trackingclass  alloc]init];
    
    trackingObj.type = @"Enter";
    trackingObj.place = region.identifier;
    trackingObj.latitude = [NSString stringWithFormat:@"%f",manager.location.coordinate.latitude];
    trackingObj.longitude = [NSString stringWithFormat:@"%f",manager.location.coordinate.longitude];
    trackingObj.time = currentTime;
    
    
    [logArray addObject:trackingObj];

}

- (void)locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region
{
    /* UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Exited" 
     message:region.identifier
     delegate:self
     cancelButtonTitle:@"OK"
     otherButtonTitles:nil, nil];
     [alert show];*/
    
    lblRegionNotified.text = @"";
    lblRegionNotified.text = [NSString stringWithFormat:@"%@%@",@"Exit - ",region.identifier];
    
    
    NSLog(@"Exit Region = %@",region.identifier);
    NSLog(@"Exit Region Latitude = %f",manager.location.coordinate.latitude);
    NSLog(@"Exit Region Longitude = %f",manager.location.coordinate.longitude);
    
    
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    // display in 12HR/24HR (i.e. 11:25PM or 23:25) format according to User Settings
    [dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
    NSString *currentTime = [dateFormatter stringFromDate:today];
    NSLog(@"User's current time in their preference format:%@",currentTime);
    
    NSLog(@"Entered Region = %@",region.identifier);
    NSLog(@"Entered Region Latitude = %f",manager.location.coordinate.latitude);
    NSLog(@"Entered Region Longitude = %f",manager.location.coordinate.longitude);
    
    trackingclass *trackingObj = [[trackingclass  alloc]init];
    
    trackingObj.type = @"Exit";
    trackingObj.place = region.identifier;
    trackingObj.latitude = [NSString stringWithFormat:@"%f",manager.location.coordinate.latitude];
    trackingObj.longitude = [NSString stringWithFormat:@"%f",manager.location.coordinate.longitude];
    trackingObj.time = currentTime;
    
    
    [logArray addObject:trackingObj];
    
    
}

- (void)locationManager:(CLLocationManager *)manager didStartMonitoringForRegion:(CLRegion *)region
{
    NSLog(@"started monitring for region: %@",region);
}

- (void) locationManager:(CLLocationManager *)manager monitoringDidFailForRegion:(CLRegion *)region withError:(NSError *)error
{
    NSLog(@"%@",error);
     NSLog(@"Region monitoring failed with error: %@", [error localizedDescription]);
}

- (IBAction)GotoLocationTracking:(id)sender {
        
    
        NSLog(@"Location Tracking Array from geolocation = %@",locationTrackingArray);
    
    locationtrackingview  *locationTracking = [[locationtrackingview alloc]initWithNibName:@"locationtrackingview" bundle:nil];  
    locationTracking.locationTrackingArray = locationTrackingArray;
    [self.navigationController pushViewController:locationTracking animated:YES];
}

- (IBAction)StartTimer:(id)sender {
    
    
    lastCapturedDate  = [NSDate date];      
    locationTimer = [NSTimer scheduledTimerWithTimeInterval:120
                                                              target:self
                                                            selector:@selector(locationUpdate)
                                                            userInfo:nil
                                                             repeats:YES];
    [locationTimer fire];
    
    //ViewController * weakSelf = self;

}

- (IBAction)StopTimer:(id)sender 
{
    [locationTimer  invalidate];
    locationTimer = nil;
    [locationManager startMonitoringSignificantLocationChanges];
}

- (IBAction)GotoViewLog:(id)sender {
    
    logview *log = [[logview alloc]initWithNibName:@"logview" bundle:nil];
    
    //log.logTrackingArray = logArray;
    [self.navigationController pushViewController:log animated:YES];
    
}

- (IBAction)RemoveViewLog:(id)sender {
    
    logArray = [[NSMutableArray alloc]init];
}
- (void)viewDidUnload
{
    [self setLblSignificantChange:nil];
    [self setLblTime:nil];
    [self setLocationScrollview:nil];
    [self setLblRegionNotified:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
       
}
- (IBAction)GotoWSCallLogView:(id)sender {
    
    wscalllogview *wsCallLog = [[wscalllogview  alloc]initWithNibName:@"wscalllogview" bundle:nil];
    [self.navigationController pushViewController:wsCallLog animated:YES];
    
    
    
}
@end
