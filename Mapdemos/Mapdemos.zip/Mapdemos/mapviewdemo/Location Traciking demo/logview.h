//
//  logview.h
//  GeoLocationDemo
//
//  Created by Harshul Shah on 18/10/13.
//  Copyright (c) 2013 shah.harshul@yahoo.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface logview : UIViewController


@property(nonatomic,retain)NSMutableArray *logTrackingArray;



@property (strong, nonatomic) IBOutlet UIScrollView *logScrollView;


-(void)BindLogTrackingData;


@end
