//
//  wscalllogclass.m
//  CouProm
//
//  Created by Harshul Shah on 25/10/13.
//  Copyright (c) 2013 Harshul Shah. All rights reserved.
//

#import "wscalllogclass.h"

@implementation wscalllogclass
@synthesize time,place;

@end
