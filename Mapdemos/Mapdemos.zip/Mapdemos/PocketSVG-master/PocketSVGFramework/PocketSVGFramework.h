//
//  PocketSVGFramework.h
//  PocketSVGFramework
//
//  Created by halseth on 24/10/15.
//

#import <UIKit/UIKit.h>

//! Project version number for PocketSVGFramework.
FOUNDATION_EXPORT double PocketSVGFrameworkVersionNumber;

//! Project version string for PocketSVGFramework.
FOUNDATION_EXPORT const unsigned char PocketSVGFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PocketSVGFramework/PublicHeader.h>

#import "PocketSVG.h"
