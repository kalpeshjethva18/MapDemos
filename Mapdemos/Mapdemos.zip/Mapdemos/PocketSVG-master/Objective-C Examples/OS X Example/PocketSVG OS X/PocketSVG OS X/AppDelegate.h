//
//  AppDelegate.h
//  PocketSVG OS X
//
//  Created by Ariel on 29/10/2012.
//  Copyright (c) 2012 Ariel. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
