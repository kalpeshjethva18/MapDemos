//
//  main.m
//  PocketSVG OS X
//
//  Created by Ariel on 29/10/2012.
//  Copyright (c) 2012 Ariel. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
