//
//  AppDelegate.h
//  Map
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import <UIKit/UIKit.h>

//@interface AppDelegate : NSObject <UIApplicationDelegate>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
