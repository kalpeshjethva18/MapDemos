//
//  ViewController.h
//  Map
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ViewController : UIViewController<MKMapViewDelegate,MKAnnotation,CLLocationManagerDelegate>
{
	IBOutlet MKMapView *mapView;
    CLLocationCoordinate2D coordinate;
	NSString *title;
	NSString *subtitle;
    CLLocation * currentLocation;
    CLLocationManager * locationManager;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, strong) MKPolylineView *lineView;
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, strong) MKPolyline *polyline;


@end
