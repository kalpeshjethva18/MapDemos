//
//  ViewController.m
//  Map
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize mapView,coordinate,title,subtitle,lineView,polyline;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [mapView setMapType:MKMapTypeStandard];
	[mapView setZoomEnabled:YES];
	[mapView setScrollEnabled:YES];
    [self.mapView setShowsUserLocation:TRUE];
    
    /*locationManager = [[CLLocationManager alloc] init];
     locationManager.delegate = self;
     [locationManager startUpdatingLocation];*/
    
	[mapView setDelegate:self];
    [self createAnnotation];
}
/*- (void)locationManager:(CLLocationManager *)manager
 didUpdateLocations:(NSArray *)locations
 {
 currentLocation = (CLLocation *)[locations lastObject];
 }*/

-(void)createAnnotation
{
    NSMutableArray* annotations=[[NSMutableArray alloc] init];
    CLLocationCoordinate2D theCoordinate1;
    theCoordinate1.latitude = 23.786996;
    theCoordinate1.longitude = 72.419281;
    
    CLLocationCoordinate2D center = CLLocationCoordinate2DMake(23.786996, 72.419281);
    MKCoordinateSpan span = MKCoordinateSpanMake(0.2, 0.2);
    MKCoordinateRegion regionToDisplay = MKCoordinateRegionMake(center, span);
    [self.mapView setRegion:regionToDisplay];
    
    CLLocationCoordinate2D theCoordinate2;
    theCoordinate2.latitude = 40.120772;
    theCoordinate2.longitude =75.118181;
    
    
    ViewController* myAnnotation1=[[ViewController alloc] init];
    myAnnotation1.coordinate=theCoordinate1;
    myAnnotation1.title=@"Ahmedabad (Level 1 trauma Center)";
    myAnnotation1.subtitle=@"";
    
    ViewController* myAnnotation2=[[ViewController alloc] init];
    myAnnotation2.coordinate=theCoordinate2;
    myAnnotation2.title=@"Muhlenberg hospital";
    myAnnotation2.subtitle=@"";
    
    
    [annotations addObject:myAnnotation1];
    [annotations addObject:myAnnotation2];
    
    
    [self.mapView addAnnotations:annotations];
    
    polyline = [MKPolyline polylineWithCoordinates:&theCoordinate2 count:2];
    [self.mapView addOverlay:polyline];
    self.polyline = polyline;
    self.lineView = [[MKPolylineView alloc]initWithPolyline:self.polyline];
    self.lineView.strokeColor = [UIColor blueColor];
    self.lineView.lineWidth = 5;
    self.title = [[NSString alloc]initWithFormat:@"%lu", (unsigned long)self.mapView.overlays.count];
    
    //Distance find
    //    CLLocation* first = [[CLLocation alloc] initWithLatitude:theCoordinate1.latitude longitude:theCoordinate1.longitude];
    //    CLLocation* second = [[CLLocation alloc] initWithLatitude:theCoordinate2.latitude longitude:theCoordinate2.longitude];
    //
    //    CGFloat distance = [first distanceFromLocation:second];
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:
(id <MKAnnotation>)annotation
{
	MKPinAnnotationView *pinView = nil;
	if(annotation != mapView.userLocation)
	{
		pinView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:nil];
		if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
										  initWithAnnotation:annotation reuseIdentifier:nil];
		pinView.pinColor = MKPinAnnotationColorRed;
		pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
	}
	else
    {
		[mapView.userLocation setTitle:@"Hi"];
	}
	return pinView;
}
/*- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    return self.lineView;
}*/
- (MKOverlayRenderer *)mapView:(MKMapView *)mapView
            rendererForOverlay:(id<MKOverlay>)overlay
{
    MKPolylineRenderer *renderer = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
    renderer.lineWidth = 5.0;
    renderer.strokeColor = [UIColor blueColor];
    return renderer;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
