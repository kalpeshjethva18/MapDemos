//
//  ViewController2.h
//  Map
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>

@interface ViewController2 : ViewController<MKMapViewDelegate,MKAnnotation>
{
    IBOutlet MKMapView *mapView2;
    CLLocationCoordinate2D coordinate2;
}
@property (nonatomic, readonly) CLLocationCoordinate2D coordinate2;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (strong, nonatomic) IBOutlet MKMapView *mapView2;
@property (nonatomic, strong) NSMutableArray *allPins;
@property (nonatomic, strong) MKPolylineView *lineView;
@property (nonatomic, strong) MKPolyline *polyline;

//- (IBAction)undoLastPin:(id)sender;

@end
