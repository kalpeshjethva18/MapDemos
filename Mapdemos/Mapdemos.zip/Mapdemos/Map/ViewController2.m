//
//  ViewController2.m
//  Map
//
//  Created by macpc on 15/10/14.
//  Copyright (c) 2014 macpc. All rights reserved.
//

#import "ViewController2.h"
#import "Pin.h"

@interface ViewController2 ()
{
    MKPinAnnotationView *Pin ;
}

- (IBAction)drawLines:(id)sender;
//- (IBAction)undoLastPin:(id)sender;

@end

@implementation ViewController2

@synthesize mapView2,coordinate2;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Please Long Press on Map and set Multiple Pin" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    
    [alert show];
    
    self.allPins = [[NSMutableArray alloc]init];
    UILongPressGestureRecognizer *recognizer = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(addPin:)];
    recognizer.minimumPressDuration = 0.5;
    [self.mapView2 addGestureRecognizer:recognizer];
}
- (void)addPin:(UIGestureRecognizer *)recognizer
{
    if (recognizer.state != UIGestureRecognizerStateBegan) {
        return;
    }
    
    CGPoint userTouch = [recognizer locationInView:self.mapView2];
    CLLocationCoordinate2D mapPoint = [self.mapView2 convertPoint:userTouch toCoordinateFromView:self.mapView2];
    Pin *newPin = [[Pin alloc]initWithCoordinate:mapPoint];
    [self.mapView2 addAnnotation:newPin];
    [self.allPins addObject:newPin];
    [self drawLines:self];
}

- (IBAction)drawLines:(id)sender
{
    [self drawLineSubroutine];
    [self drawLineSubroutine];
}

- (void)drawLineSubroutine {
    
    [self.mapView2 removeOverlay:self.polyline];
    CLLocationCoordinate2D coordinates[self.allPins.count];
    int i = 0;
    for (Pin *currentPin in self.allPins) {
        coordinates[i] = currentPin.coordinate;
        i++;
    }
    
    MKPolyline *polyline = [MKPolyline polylineWithCoordinates:coordinates count:self.allPins.count];
    [self.mapView2 addOverlay:polyline];
    self.polyline = polyline;
    self.lineView = [[MKPolylineView alloc]initWithPolyline:self.polyline];
    self.lineView.strokeColor = [UIColor blueColor];
    self.lineView.lineWidth = 5;
    self.title = [[NSString alloc]initWithFormat:@"%lu", (unsigned long)self.mapView2.overlays.count];
}
-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:
(id <MKAnnotation>)annotation
{
	MKPinAnnotationView *pinView = nil;
    
	if(annotation != mapView2.userLocation)
	{
		pinView = (MKPinAnnotationView *)[mapView2 dequeueReusableAnnotationViewWithIdentifier:nil];
		if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
                                         initWithAnnotation:annotation reuseIdentifier:nil];
		pinView.pinColor = MKPinAnnotationColorRed;
		pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
    }
	else {
		[mapView2.userLocation setTitle:@"I am here"];
	}
	return pinView;
}

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay {
    
    return self.lineView;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
@end
